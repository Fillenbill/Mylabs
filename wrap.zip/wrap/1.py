import example

obj = example.Example(10)
print(obj.getValue())  # Вывод: 10
obj.setValue(20)
print(obj.getValue())  # Вывод: 20
