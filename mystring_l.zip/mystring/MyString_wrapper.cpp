#include <boost/python.hpp>
#include "MyString.h"
#include <boost/python/module.hpp>

namespace py = boost::python;

BOOST_PYTHON_MODULE(MyString) {
    py::class_<MyString>("MyString")
        .def(py::init<>())
        .def(py::init<const char*>())
        .def(py::init<const std::string&>())
        .def(py::init<const char*, int>())
        .def(py::init<int, char>())
        .def(py::init<const MyString&>());

        //.def("find", static_cast<int(MyString::*)(const char*)>(&MyString::find));
    //   .def("find", static_cast<int(MyString::*)(const char*, int)>(&MyString::find)) 
      //   .def("find", static_cast<int(MyString::*)(const std::string&)>(&MyString::find))
        // .def("find", static_cast<int(MyString::*)(const std::string&, int)>(&MyString::find))

        // .def("getitem", [](const MyString& s, int index) { return s[index]; })
        // .def("setitem", [](MyString& s, int index, char value) { s[index] = value; });
}