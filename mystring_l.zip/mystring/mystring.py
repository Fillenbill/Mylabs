import mystring

obj = mystring.str("hello!")
print(mystring.str)

