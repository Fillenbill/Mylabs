﻿#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstring>
#include "MyString.h"
//#include "test_all.h"

using namespace std;

//-----------------------------------------Constructors-----------------------------------------//

MyString::MyString(const char* p_name, int count)
{
    attr_size = count;
    attr_capacity = attr_size + 1;
    str = new char[attr_capacity];
    memcpy(str, p_name, count);
    str[count] = '\0';
}

MyString::MyString() : MyString("", 0) {}
MyString::MyString(const char* p_name) : MyString(p_name, strlen(p_name)) {}
MyString::MyString(const string std_string) : MyString(std_string.c_str()) {}
MyString::MyString(const MyString& other) : MyString(other.str, other.attr_size) {}

MyString::MyString(int count, char c_name)
{
    int i;
    attr_size = count;
    attr_capacity = count + 1;
    str = new char[attr_capacity];
    for (i = 0; i < count; i++) {
        str[i] = c_name;
    };
    str[i] = '\0';
}


MyString::MyString(MyString&& other) noexcept
    : str(other.str), attr_size(other.attr_size), attr_capacity(other.attr_capacity)
{
    other.str = nullptr;
    other.attr_size = 0;
    other.attr_capacity = 0;
}

MyString::~MyString()
{
    if (str != nullptr) {
        delete[] str;
        str = nullptr;
    }
    attr_capacity = 0;
    attr_size = 0;
}


//-----------------------------------------Functions-----------------------------------------//

char* MyString::c_str()
{
    str[attr_size] = '\0';
    return str;
}

char* MyString::data()
{
    return str;
}

size_t MyString::length() const
{
    return size();
}

int MyString::size() const
{
    return attr_size;
}

bool MyString::empty()
{
    return attr_size == 0;
}

int MyString::capacity() const
{
    return attr_capacity;
}

void MyString::shrink_to_fit() {
    if (attr_capacity > attr_size + 1) {
        char* new_str = new char[attr_size + 1];
        memcpy(new_str, str, attr_size);
        new_str[attr_size] = '\0';
        delete[] str;
        str = new_str;
        attr_capacity = attr_size + 1;
    }
}

void MyString::clear()
{
    delete[] str;
    str = new char[1];
    *str = '\0';
    attr_size = 0;
}

//-----------------------------------------Insert-----------------------------------------//

void MyString::insert(size_t index, size_t count, char c_name)
{
    if (index > attr_size) {
        index = attr_size;
    }

    char* new_str = new char[attr_size + count + 1];
    memcpy(new_str, str, index);
    memset(new_str + index, c_name, count);
    memcpy(new_str + index + count, str + index, attr_size - index);
    new_str[attr_size + count] = '\0';

    delete[] str;
    str = new_str;
    attr_size += count;
    attr_capacity = attr_size + 1;
}

void MyString::insert(size_t index, const char* p_name)
{
    insert(index, p_name, strlen(p_name));
}

void MyString::insert(size_t index, const char* p_name, size_t count)
{
    if (index > attr_size) {
        index = attr_size;
    }

    char* new_str = new char[attr_size + count + 1];
    memcpy(new_str, str, index);
    memcpy(new_str + index, p_name, count);
    memcpy(new_str + index + count, str + index, attr_size - index);
    new_str[attr_size + count] = '\0';

    delete[] str;
    str = new_str;
    attr_size += count;
    if (attr_capacity < attr_size) {
        attr_capacity = attr_size + 1;
    }
}

void MyString::insert(size_t index, const string s_name)
{
    insert(index, s_name.c_str());
}

void MyString::insert(size_t index, const string s_name, size_t count)
{
    insert(index, s_name.c_str(), count);
}

//-----------------------------------------Erase-----------------------------------------//

void MyString::erase(size_t index, size_t count)
{
    if (index >= attr_size) {
        return;
    }
    if (index + count > attr_size) {
        count = attr_size - index;
    }
    memmove(str + index, str + index + count, attr_size - index - count);
    attr_size -= count;
    str[attr_size] = '\0';
}

//-----------------------------------------Append-----------------------------------------//
void MyString::append(size_t count, char c_name)
{
    insert(attr_size, count, c_name);
}

void MyString::append(const char* p_name)
{
    insert(attr_size, p_name);
}

void MyString::append(const char* p_name, size_t index, const size_t count)
{
    if (index >= strlen(p_name)) {
        return;
    }

    size_t actual_count = count;
    if (index + count > strlen(p_name)) {
        actual_count = strlen(p_name) - index;
    }

    insert(attr_size, p_name + index, actual_count);
}

void MyString::append(string s_name)
{
    append(s_name.c_str());
}

void MyString::append(string s_name, const size_t index, const size_t count)
{
    append(s_name.c_str(), index, count);
}

//-----------------------------------------Replace-----------------------------------------//
void MyString::replace(size_t index, size_t count, const char* p_name)
{
    
    if (index >= attr_size) {
        return;
    }
    erase(index, count);
    insert(index, p_name);
    
}

void MyString::replace(size_t index, size_t count, const string s_name)
{
    replace(index, count, s_name.c_str());
}

//-----------------------------------------Substr-----------------------------------------//
MyString MyString::substr(size_t index, size_t count) const {
    if (index >= attr_size) {
        return MyString();
    }

    if (index + count > attr_size) {
        count = attr_size - index;
    }

    MyString result;
    result.attr_size = count;
    result.attr_capacity = count + 1;
    result.str = new char[result.attr_capacity];
    std::memcpy(result.str, str + index, count);
    result.str[count] = '\0';

    return result;
}

MyString MyString::substr(size_t index) const {
    return substr(index, attr_size - index);
}

//-----------------------------------------Find-----------------------------------------//

int MyString::find(const char* p_name) const
{
    return find(p_name, 0);
}

int MyString::find(const char* p_name, size_t counter) const
{
    size_t l = strlen(p_name);
    for (size_t index = counter; index <= attr_size - l; index++) {
        if (str[index] == p_name[0]) {
            size_t i;
            for (i = 0; i < l; i++) {
                if (str[index + i] != p_name[i]) {
                    break;
                }
            }
            if (i == l) {
                return index;
            }
        }
    }
    return -1;
}
int MyString::find(const string s_name) const
{
    return find(s_name.c_str());
}

int MyString::find(const string s_name, size_t counter) const
{
    return find(s_name.c_str(), counter);
}

//-----------------------------------------Operators-----------------------------------------//

MyString MyString::operator+(const MyString& other) const
{
    MyString result(*this);
    result.append(other.str);
    return result;
}

MyString MyString::operator+(const char* p_name) const
{
    MyString result(*this);
    result.append(p_name);
    return result;
}

MyString MyString::operator+(const string s_name) const
{
    MyString result(*this);
    result.append(s_name);
    return result;
}

MyString& MyString::operator+=(const MyString& other)
{
    this->append(other.str);
    return *this;
}

MyString& MyString::operator+=(const char* p_name)
{
    this->append(p_name);
    return *this;
}

MyString& MyString::operator+=(string s_name)
{
    this->append(s_name.c_str());
    return *this;
}

MyString& MyString::operator=(MyString&& other) noexcept
{
    if (this != &other)
    {
        delete[] str;
        str = other.str;
        attr_size = other.attr_size;
        attr_capacity = other.attr_capacity;
        other.str = nullptr;
        other.attr_size = 0;
        other.attr_capacity = 0;
    }
    return *this;
}

MyString& MyString::operator=(const MyString& other)
{
    if (this != &other) {
      
        this->clear();
        this->insert(0, other.str);
        
    }
    return *this;
}

MyString& MyString::operator=(const char* p_name)
{
    size_t l = strlen(p_name);
    if (l + 1 > attr_capacity) {
        delete[] str;
        attr_capacity = l + 1;
        str = new char[attr_capacity];
    }
    attr_size = l;
    std::memcpy(str, p_name, l);
    str[l] = '\0';
    return *this;
}

MyString& MyString::operator=(const string s_name)
{
    return *this = s_name.c_str();
}

MyString& MyString::operator=(char c_name)
{
    delete[] str;
    attr_size = 1;
    attr_capacity = 2;
    str = new char[attr_capacity];
    str[0] = c_name;
    str[1] = '\0';
    return *this;
}

char& MyString::operator[](size_t index)
{
    if (index >= attr_size)
    {
        throw std::out_of_range("Index out of range");
    }
    return str[index];
}

const char& MyString::operator[](size_t index) const
{
    if (index >= attr_size)
    {
        throw std::out_of_range("Index out of range");
    }
    return str[index];
}

ostream& operator<<(ostream& os, const MyString& myStr)
{
    os << myStr.str;
    return os;
}

std::istream& operator>>(std::istream& in, MyString& input_value) {
    const int max_length = 5000;
    char buffer[max_length + 1];
    int index = 0;

    while (in.get(buffer[index]) && buffer[index] != '\n') {
        if (index < max_length) {
            index++;
        }
        else {
            break;
        }
    }

    buffer[index] = '\0';
    input_value = buffer;
    return in;
}

bool MyString::operator>(const MyString& other) const {
    size_t len = std::min(attr_size, other.attr_size);
    for (size_t i = 0; i < len; ++i) {
        if (str[i] > other.str[i]) return true;
        if (str[i] < other.str[i]) return false;
    }
    return attr_size > other.attr_size;
}

bool MyString::operator<(const MyString& other) const {
    size_t len = std::min(attr_size, other.attr_size);
    for (size_t i = 0; i < len; ++i) {
        if (str[i] < other.str[i]) return true;
        if (str[i] > other.str[i]) return false;
    }
    return attr_size < other.attr_size;
}

bool MyString::operator>=(const MyString& other) const {
    return !(*this < other);
}

bool MyString::operator<=(const MyString& other) const {
    return !(*this > other);
}

bool MyString::operator!=(const MyString& other) const {
    return !(this->operator==(other));
}

bool MyString::operator==(const MyString& other) const {
    if (attr_size != other.attr_size) return false;
    for (size_t i = 0; i < attr_size; ++i) {
        if (str[i] != other.str[i]) return false;
    }
    return true;
}

//-----------------------------------------Main-----------------------------------------//

int main()
{
    setlocale(LC_ALL, "");
    //test();
    cout << "Hola";

}
