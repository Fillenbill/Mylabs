#define _CRT_SECURE_NO_WARNINGS
#ifndef _MYSTRING_H_
#define _MYSTRING_H_
using namespace std;
class MyString {

private:
	char* str;
	int attr_size = 0;
	int attr_capacity = 0;

public:

	MyString();
	MyString(const char* p_name);
	MyString(const string s_name);
	MyString(const char* p_name, int count);
	MyString(int count, char c_name);
	MyString(const MyString &obj);
	MyString(MyString&& other) noexcept;
	~MyString();
	
	char* c_str();
	char* data();
	size_t length() const;
	int size() const;
	bool empty();
	int capacity() const ;
	void shrink_to_fit();
	void clear();


	MyString operator+(const MyString& other) const;
	MyString operator+(const char* p_name) const;
	MyString operator+(const string s_name) const;
	MyString& operator+=(const MyString& other);
	MyString& operator+=(const char* p_name);
	MyString& operator+=(const string s_name);
	MyString& operator=(MyString&& other) noexcept;
	MyString& operator=(const MyString& other);
	MyString& operator=(const char* p_name);
	MyString& operator=(const string s_name);
	MyString& operator=(char c_name);
	char& operator[](size_t index);
	const char& operator[](size_t index) const;
	bool operator >(const MyString& other) const;
	bool operator <(const MyString& other) const;
	bool operator >=(const MyString& other) const;
	bool operator <=(const MyString& other) const;
	bool operator !=(const MyString& other) const;
	bool operator ==(const MyString& other) const;


	void insert(size_t index, size_t count, char c_name);
	void insert(size_t index, const char* p_name);
	void insert(size_t index, const char* p_name, size_t count);
	void insert(size_t index, const string s_name);
	void insert(size_t index, const string s_name, size_t count);

	void erase(size_t index, size_t count);

	void append(size_t count, char c_name);
	void append(const char* p_name);
	void append(const char* p_name, size_t index, const size_t count);
	void append(string s_name);
	void append(string s_name, const size_t index, const size_t count);

	void replace(size_t index, size_t count, const char* p_name);
	void replace(size_t index, size_t count, const string s_name);

	MyString substr(size_t index, size_t count) const;
	MyString substr(size_t index) const;

	int find(const char* p_nmae) const;
	int find(const char* p_name, size_t index) const;
	int find(const string s_name) const;
	int find(const string s_name, size_t index) const;
	
	friend std::istream& operator>>(std::istream& in, MyString& input_value);
	friend std::ostream& operator<<(std::ostream& os, const MyString& myStr);
	

};

#endif // _MYSTRING_H_
